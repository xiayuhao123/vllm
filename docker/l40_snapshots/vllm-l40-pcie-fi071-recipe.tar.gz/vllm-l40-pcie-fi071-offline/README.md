# vLLM 0.30.0 + L40 A + FlashInfer PCIe IPC 离线实验镜像

本包基于你已经构建的 `vllm/vllm-openai:v0.30.0-l40-a`，更新 FlashInfer 并补齐依赖。
它保留现有 vLLM Python 修改、CUDA 扩展、PyTorch 和 NVIDIA 运行库。

## 版本与范围

- Linux x86_64、Python 3.12、Torch 2.13.0+cu130、CUDA 13.0。
- FlashInfer Python/cubin：0.7.0.post1。
- FlashInfer JIT cache shim 与 SM89 provider：0.7.0.post1+cu130。
- nccl-extensions：0.1.0；cuda-core 1.0.0 / cuda-pathfinder 1.5.4 仅在当前版本不满足要求时安装。
- wheel 全部来自官方 GitHub release 或 PyPI，来源、大小、SHA256 记录在 `wheel_sources.json`。
- 安装使用 `--no-index --no-deps`，不联网解析依赖。缺少其他必要依赖时构建会报出名字。

这是实验依赖升级：vLLM 0.30.0 原本固定 FlashInfer 0.6.18.post1；本包没有伪造版本或修改依赖声明。
此外只安装 SM89 缓存，官方 shim 的元数据还列出了其他架构 provider。
因此 `pip check` 可能报告 vLLM 的 FlashInfer 固定版本冲突及未安装其他架构缓存。
这些是已知的选择，不代表任意其他依赖冲突都可以忽略。本包的安装脚本检查所选 wheel 的其他依赖。
本镜像仅用于 L40/SM89 测试，不作为其他架构的预编译缓存镜像。

源码核对了 vLLM PCIe 包装器调用的 constructor / tune / prepare / supports / all_reduce /
rebind_stream / destroy 接口。没有在这里的环境执行 vLLM Docker 构建或 L40 GPU 测试；
不能据此认定模型推理、CUDA Graph 或数值质量已经验证。

## 内网构建

将整个压缩包传入内网后解压并进入目录：

```bash
tar -xzf vllm-l40-pcie-fi071-offline.tar.gz
cd vllm-l40-pcie-fi071-offline
sha256sum -c SHA256SUMS
BASE_IMAGE='vllm/vllm-openai:v0.30.0-l40-a'
NEW_IMAGE='vllm/vllm-openai:v0.30.0-l40-a-fi071'
docker build --progress=plain --pull=false --network=none --build-arg BASE_IMAGE="$BASE_IMAGE" -t "$NEW_IMAGE" .
```

需要 Docker BuildKit（你前面使用的构建方式已经是 BuildKit）。wheel 通过构建时 bind mount 读取，
不会额外复制一份压缩 wheel 到最终镜像。这个包约 1.7 GB，构建会解包 CUDA 内核，
不能用前面 A 的 5 秒构建时间作预期；保留足够的磁盘空间。

构建成功的必要输出包含 `PCIe IPC API: available` 和 SM89 cache provider。
该 SM89 缓存包含 `pcie_ipc_comm`，实际是否命中仍取决于运行时版本和缓存匹配；
若未命中则可能使用镜像内 nvcc 在首次启动时编译。无需在宿主机安装 CUDA 编译器。

## 先运行两卡验证

在 GPU 2、3 空闲时执行。此步骤不加载模型，检查 PCIe IPC 的 eager 与 CUDA Graph 归约结果。

```bash
docker run --rm --gpus '"device=2,3"' --ipc=host --network=none --entrypoint torchrun "$NEW_IMAGE" --standalone --nproc-per-node=2 /opt/vllm-pcie/smoke_pcie.py
```

预期输出：`PASS: TP2 BF16 [1, 5120]`，以及 batch 4、16、32 的 PASS，最后显示整体 PASS。
首次运行可能有初始化、编译、调优等待；此脚本只测正确性，不测性能。
若报 peer access、CUDA IPC、编译错误或超时，请保留完整日志，此时先不要扩大模型测试。

## 再运行模型

使用你目前的完整启动命令，将镜像名替换为 `vllm/vllm-openai:v0.30.0-l40-a-fi071`。
保留以下设置：

```bash
-e VLLM_ALLREDUCE_USE_FLASHINFER_PCIE_IPC=1
-e VLLM_ENABLE_SM89_FP8_SPLIT_K=1
--kernel-config '{"linear_backend_per_quant":{"fp8_block_w8a8":"triton"}}'
```

请把上述三行分别放回原命令的环境变量区域、环境变量区域和 vLLM 参数区域；
它们不是独立的 shell 命令。其他参数先保持相同，包括 MTP=3。

查看日志：

```bash
docker logs qwen38-fp8-30-l40-a 2>&1 | grep -Ei 'Initialized FlashInfer PCIe|all-reduce backends|PCIe IPC|Selected.*Fp8|cudagraph|ERROR|Traceback'
```

应出现 `Initialized FlashInfer PCIe IPC all-reduce for TP2, hidden_dim=5120`，
且启用的 all-reduce backends 包含 `FLASHINFER_PCIE_IPC`。
这些日志确认初始化与后端配置；只有符合后端形状/容量约束的归约才走这个路径。
不符合条件的输入仍可以回退 CUSTOM / PYNCCL。

## 如何比较

使用同一个新镜像，分别设置 `VLLM_ALLREDUCE_USE_FLASHINFER_PCIE_IPC=0` 和 `1`。
保持 A、Triton、MTP、提示词、输入输出长度及并发相同，预热后比较单路和四并发。
每组重复至少三次，记录总输出 tokens/s、每请求 TPOT、输出质量和错误日志。
这样可以区分 PCIe 后端收益与 FlashInfer 更新本身的影响。
再与旧的 A 镜像比较，判断整个依赖升级是否值得保留。

此升级不会校准 FP8 KV scale，也不保证解除 MTP 的 CUDA Graph 降级。
低 Tensor Core 利用率也不能单独证明通信瓶颈或 PCIe IPC 的收益。

## 当前 Triton 日志的含义

`Selected TritonFp8BlockScaledMMKernel` 表明原本被 Marlin 绕开的 Triton 路径已经选中。
A 主开关针对小 M 的 N=5120,K=3072 与 N=5120,K=8704；你已看到前一个形状。
`Using default ... config` 仍可能出现，它表示没有形状调优 JSON，不能单凭此警告判断 A 开关失效。
N=8192,K=5120 是独立的实验开关，目前不应顺手打开，先验证主开关收益。

## 回退

关闭 PCIe 环境变量可以回退通信后端，但 FlashInfer 仍为 0.7。
完整依赖回退需要使用原来的 `vllm/vllm-openai:v0.30.0-l40-a` 镜像。

官方来源：
- https://github.com/flashinfer-ai/flashinfer/releases/tag/v0.7.0
- https://github.com/flashinfer-ai/flashinfer/releases/tag/v0.7.0.post1
- https://pypi.org/project/flashinfer-python/0.7.0.post1/
- https://pypi.org/project/nccl-extensions/0.1.0/
