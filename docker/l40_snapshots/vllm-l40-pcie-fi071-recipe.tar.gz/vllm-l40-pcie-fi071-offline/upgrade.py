"""Install the fixed L40/CUDA 13.0 wheel set without resolving dependencies."""

import hashlib
import json
import platform
import shutil
import subprocess
import sys
from email.parser import BytesParser
from importlib import metadata
from pathlib import Path
from zipfile import ZipFile

from packaging.requirements import Requirement
from packaging.utils import canonicalize_name
from packaging.version import Version


def installed_versions():
    return {
        canonicalize_name(d.metadata["Name"]): d.version
        for d in metadata.distributions()
        if d.metadata["Name"]
    }


def required_dependencies(message, versions, *, sm89_only=False):
    errors = []
    for text in message.get_all("Requires-Dist", []):
        req = Requirement(text)
        if req.marker and not req.marker.evaluate({"extra": ""}):
            continue
        name = canonicalize_name(req.name)
        # The official shim lists all GPU architectures. This image includes
        # only the SM89 provider, deliberately installed with --no-deps.
        if (
            sm89_only
            and name.startswith("flashinfer-jit-cache-sm")
            and name != "flashinfer-jit-cache-sm89"
        ):
            continue
        version = versions.get(name)
        if version is None or Version(version) not in req.specifier:
            errors.append(f"{message['Name']} needs {req}; installed/planned {version}")
    if errors:
        raise RuntimeError("Unsatisfied dependencies:\n" + "\n".join(errors))


def main():
    import torch

    if platform.system() != "Linux" or platform.machine() != "x86_64":
        raise RuntimeError("This bundle is for Linux x86_64 only")
    if sys.version_info[:2] != (3, 12):
        raise RuntimeError("This bundle requires Python 3.12")
    before = installed_versions()
    expected = {
        "vllm": "0.30.0",
        "torch": "2.13.0+cu130",
        "flashinfer-python": "0.6.18.post1",
        "flashinfer-cubin": "0.6.18.post1",
        "flashinfer-jit-cache": "0.6.18.post1+cu130",
    }
    for name, version in expected.items():
        if before.get(name) != version:
            raise RuntimeError(f"Expected {name} {version}, got {before.get(name)}")
    if torch.version.cuda != "13.0" or not shutil.which("nvcc"):
        raise RuntimeError("Expected CUDA 13.0 and nvcc in the base image")

    root = Path(__file__).resolve().parent
    sources = json.loads((root / "wheel_sources.json").read_text())
    wheels = {}
    for source in sources:
        path = Path("/opt/flashinfer-wheels") / source["name"]
        with path.open("rb") as file:
            digest = hashlib.file_digest(file, "sha256").hexdigest()
        if digest != source["sha256"] or path.stat().st_size != source["size"]:
            raise RuntimeError(f"Wheel checksum/size mismatch: {path.name}")
        with ZipFile(path) as archive:
            meta_path = next(
                n for n in archive.namelist() if n.endswith(".dist-info/METADATA")
            )
            message = BytesParser().parsebytes(archive.read(meta_path))
        name = canonicalize_name(message["Name"])
        wheels[name] = (path, message)

    selected = [
        "flashinfer-python",
        "flashinfer-cubin",
        "flashinfer-jit-cache",
        "flashinfer-jit-cache-sm89",
        "nccl-extensions",
    ]
    # Keep existing compatible CUDA helpers. Supply them only when needed.
    for name, spec in (
        ("cuda-core", "cuda-core~=1.0"),
        ("cuda-pathfinder", "cuda-pathfinder>=1.5.4,<2"),
    ):
        current = before.get(name)
        if current is None or Version(current) not in Requirement(spec).specifier:
            selected.append(name)
    planned = dict(before)
    planned.update({name: wheels[name][1]["Version"] for name in selected})
    for name in selected:
        required_dependencies(
            wheels[name][1], planned, sm89_only=name == "flashinfer-jit-cache"
        )

    # Remove the old monolithic cache before installing the new shim/provider.
    subprocess.run(
        [sys.executable, "-m", "pip", "uninstall", "-y", "flashinfer-jit-cache"],
        check=True,
    )
    subprocess.run(
        [
            sys.executable,
            "-m",
            "pip",
            "install",
            "--no-index",
            "--no-deps",
            "--no-cache-dir",
            *[str(wheels[name][0]) for name in selected],
        ],
        check=True,
    )
    after = installed_versions()
    for name, version in before.items():
        if name not in selected and after.get(name) != version:
            raise RuntimeError(
                f"Unexpected package change: {name}: {version} -> {after.get(name)}"
            )
    for name in selected:
        if after.get(name) != planned[name]:
            raise RuntimeError(f"Installed version mismatch: {name}")
        required_dependencies(
            wheels[name][1], after, sm89_only=name == "flashinfer-jit-cache"
        )

    # Use a fresh interpreter after replacing imported packages/metadata.
    subprocess.run(
        [
            sys.executable,
            "-c",
            """
import torch
import flashinfer.comm as comm
from flashinfer_jit_cache import get_jit_cache_providers
assert hasattr(comm, "PcieIpcAllReduceWorkspace"), "PCIe IPC API missing"
providers = get_jit_cache_providers()
assert any("sm89" in p.cuda_architectures for p in providers), "SM89 cache missing"
print("PCIe IPC API: available")
print("Cache providers:", [(p.provider_id, p.version) for p in providers])
print("Torch:", torch.__version__, "CUDA:", torch.version.cuda)
""",
        ],
        check=True,
    )
    print(
        "Offline installation verified. L40 GPU/runtime validation is still required."
    )


if __name__ == "__main__":
    main()
