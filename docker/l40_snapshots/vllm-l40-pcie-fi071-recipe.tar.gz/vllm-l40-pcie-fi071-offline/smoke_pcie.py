"""TP2 correctness test for eager and CUDA Graph PCIe IPC all-reduce."""

import os
from datetime import timedelta

import torch
import torch.distributed as dist
from flashinfer.comm import PcieIpcAllReduceWorkspace


def main():
    torch.cuda.set_device(int(os.environ["LOCAL_RANK"]))
    if torch.cuda.get_device_capability() != (8, 9):
        raise RuntimeError("This test targets SM89 GPUs")
    dist.init_process_group("nccl", timeout=timedelta(minutes=10))
    workspace = None
    tune_group = None
    try:
        if dist.get_world_size() != 2:
            raise RuntimeError("Run with torchrun --nproc-per-node=2")
        tune_group = dist.new_group(backend="gloo", timeout=timedelta(minutes=10))
        batches = (1, 4, 16, 32)
        hidden = 5120
        dtype = torch.bfloat16
        rank = dist.get_rank()
        workspace = PcieIpcAllReduceWorkspace(
            group=dist.group.WORLD,
            max_numel=max(batches) * hidden,
            dtype=dtype,
            tune_batches=batches,
            tune_cache="/tmp/flashinfer-pcie-smoke-tp2.json",
        )
        workspace.tune([hidden], dtype=dtype, tune_group=tune_group)
        configs = workspace.prepare([(m, hidden) for m in batches], dtype=dtype)
        for batch in batches:
            if configs[(batch, hidden)] is None:
                raise RuntimeError(f"Unsupported PCIe IPC shape: {batch}, {hidden}")
            # Distinct random inputs on each rank exercise the actual reduction.
            torch.manual_seed(2026 + rank + batch)
            inp = torch.randn((batch, hidden), device="cuda", dtype=dtype)
            expected = inp.clone()
            dist.all_reduce(expected)
            result = workspace.all_reduce(inp)
            torch.testing.assert_close(result, expected, rtol=0.01, atol=0.01)
            torch.cuda.synchronize()
            workspace.rebind_stream()
            graph = torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):
                captured = workspace.all_reduce(inp)
            graph.replay()
            torch.cuda.synchronize()
            torch.testing.assert_close(captured, expected, rtol=0.01, atol=0.01)
            # Replay with new input so stale-output errors cannot pass.
            inp.mul_(0.5)
            graph.replay()
            torch.cuda.synchronize()
            torch.testing.assert_close(captured, expected * 0.5, rtol=0.01, atol=0.01)
            workspace.rebind_stream()
            if rank == 0:
                print(
                    f"PASS: TP2 BF16 [{batch}, {hidden}], eager + graph replay",
                    flush=True,
                )
        dist.barrier()
        if rank == 0:
            print(
                "PASS: PCIe IPC correctness smoke test (no performance claim).",
                flush=True,
            )
    finally:
        if workspace is not None:
            workspace.destroy()
        if tune_group is not None:
            dist.destroy_process_group(tune_group)
        dist.destroy_process_group()


if __name__ == "__main__":
    main()
