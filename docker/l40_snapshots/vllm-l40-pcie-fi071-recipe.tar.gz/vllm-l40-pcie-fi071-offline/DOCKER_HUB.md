# 通过 Docker Hub 把 FlashInfer 离线依赖传入内网

外网构建一个只包含依赖文件的镜像，推到你自己的 Docker Hub 账号。
内网拉取该镜像，再以本地 A 镜像为基础安装依赖，不需要传入 1.6 GB 压缩包。
传输数据量仍约 1.7 GB，只是使用 Docker 镜像下载通道。

## 外网电脑

在本离线包目录执行。`Dockerfile.payload` 使用 scratch，不需要拉取基础镜像，也不执行 wheel。
固定平台为 linux/amd64，因为内网服务器是 x86_64。

```bash
DOCKERHUB_USER='jackie33456'
PAYLOAD_IMAGE="$DOCKERHUB_USER/vllm-l40-deps:fi071-cu130-sm89"

docker build --platform linux/amd64 --pull=false --network=none -f Dockerfile.payload -t "$PAYLOAD_IMAGE" .
docker login
docker push "$PAYLOAD_IMAGE"
```

如果直接使用本次已经在 Codex 所在电脑构建好的本地镜像，可以用 tag 替代上面的 build：

```bash
docker tag vllm-l40/flashinfer-offline:0.7.0.post1-cu130-sm89 "$PAYLOAD_IMAGE"
docker login
docker push "$PAYLOAD_IMAGE"
```

本次没有代你登录或推送 Docker Hub。文件镜像仅承载官方 wheel 和安装脚本，未包含模型权重。
它不是可运行的 vLLM 镜像，不要 docker run 这个文件镜像。

## 内网电脑

下载很小的 `Dockerfile.registry`，或者直接粘贴下面内容。
这个文件使用 BuildKit 的跨阶段文件挂载，不需要把 wheel 导出到宿主机。

```bash
mkdir -p vllm-l40-fi071-from-registry
cd vllm-l40-fi071-from-registry

cat > Dockerfile <<'EOF'
ARG BASE_IMAGE=vllm/vllm-openai:v0.30.0-l40-a
ARG PAYLOAD_IMAGE=vllm-l40/flashinfer-offline:0.7.0.post1-cu130-sm89
FROM ${PAYLOAD_IMAGE} AS payload
FROM ${BASE_IMAGE}
COPY --from=payload /payload/upgrade.py /payload/smoke_pcie.py /payload/wheel_sources.json /opt/vllm-pcie/
RUN --mount=type=bind,from=payload,source=/payload/wheels,target=/opt/flashinfer-wheels \
    python3 /opt/vllm-pcie/upgrade.py
EOF

DOCKERHUB_USER='jackie33456'
PAYLOAD_IMAGE="$DOCKERHUB_USER/vllm-l40-deps:fi071-cu130-sm89"
NEW_IMAGE='vllm/vllm-openai:v0.30.0-l40-a-fi071'

# 若 Docker Hub 仓库是私有的，先在内网 docker login。
docker pull "$PAYLOAD_IMAGE"
docker build --progress=plain --pull=false --network=none \
  --build-arg BASE_IMAGE='vllm/vllm-openai:v0.30.0-l40-a' \
  --build-arg PAYLOAD_IMAGE="$PAYLOAD_IMAGE" \
  -t "$NEW_IMAGE" .
```

这里最终构建仍要求内网已经有 `vllm/vllm-openai:v0.30.0-l40-a`。
安装检查与原离线方案相同：固定版本、wheel 校验、不自动解析依赖，并核对已有 PyTorch / NVIDIA 包未变化。
首次 GPU 验证和模型测试仍然必须执行。

## 两卡验证

在 GPU 2、3 空闲时运行：

```bash
docker run --rm --gpus '"device=2,3"' --ipc=host --network=none --entrypoint torchrun "$NEW_IMAGE" --standalone --nproc-per-node=2 /opt/vllm-pcie/smoke_pcie.py
```

出现所有 PASS 后，用新镜像运行原来的模型命令并保留 PCIe 开关。
此依赖升级仍是实验方案，尚未在这里验证 L40 模型推理或性能。

## 如果希望把文件提取出来

Docker 支持从未启动的容器复制文件。这个 scratch 镜像没有运行环境，因此只 create，不 start：

```bash
docker create --name fi071-payload "$PAYLOAD_IMAGE"
mkdir -p extracted-fi071
docker cp fi071-payload:/payload/. ./extracted-fi071/
docker rm fi071-payload
```

提取后 `extracted-fi071` 包含旧离线构建的 Dockerfile、安装脚本和 wheels，可以继续原来的构建方法。
