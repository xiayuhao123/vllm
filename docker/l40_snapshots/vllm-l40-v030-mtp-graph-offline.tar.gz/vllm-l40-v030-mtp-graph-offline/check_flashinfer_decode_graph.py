"""GPU smoke: fixed FP8-KV wrapper / fast_plan_decode across page boundaries.

Run inside the serving image, outside a timed benchmark. This tests the native
FlashInfer primitive, not the complete MTP model or TP communication.
"""

import argparse
import math


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--requests", type=int, nargs="+", default=[1, 3, 4])
    parser.add_argument("--head-dim", type=int, default=128)
    parser.add_argument("--qo-heads", type=int, default=4)
    parser.add_argument("--kv-heads", type=int, default=2)
    args = parser.parse_args()
    if any(n < 1 or n > 8 for n in args.requests):
        parser.error("--requests must be within 1..8")
    if args.qo_heads % args.kv_heads:
        parser.error("--qo-heads must be divisible by --kv-heads")

    import torch
    from flashinfer import BatchDecodeWithPagedKVCacheWrapper
    from vllm.v1.attention.backends.flashinfer import fast_plan_decode

    if not torch.cuda.is_available() or torch.cuda.get_device_capability(0) != (8, 9):
        raise SystemExit("This smoke check requires CUDA SM89.")
    device = torch.device("cuda:0")
    print("GPU:", torch.cuda.get_device_name(device))
    page_size = 64
    boundaries = (63, 64, 65, 127, 128, 129, 511, 512, 513, 16383, 16384, 16385)
    checked = 0
    with torch.inference_mode():
        for n in args.requests:
            max_pages = math.ceil((max(boundaries) + n) / page_size)
            kv = torch.randn(
                n * max_pages,
                2,
                page_size,
                args.kv_heads,
                args.head_dim,
                dtype=torch.bfloat16,
                device=device,
            ).to(torch.float8_e4m3fn)
            q = torch.randn(
                n, args.qo_heads, args.head_dim, dtype=torch.bfloat16, device=device
            )
            indptr = torch.empty(n + 1, dtype=torch.int32, device=device)
            indices = torch.empty(n * max_pages, dtype=torch.int32, device=device)
            last_page = torch.empty(n, dtype=torch.int32, device=device)
            workspace = torch.zeros(128 << 20, dtype=torch.uint8, device=device)
            reference_workspace = torch.zeros_like(workspace)
            wrapper = BatchDecodeWithPagedKVCacheWrapper(
                workspace,
                "NHD",
                use_cuda_graph=True,
                use_tensor_cores=True,
                paged_kv_indptr_buffer=indptr,
                paged_kv_indices_buffer=indices,
                paged_kv_last_page_len_buffer=last_page,
            )
            reference = BatchDecodeWithPagedKVCacheWrapper(
                reference_workspace, "NHD", use_tensor_cores=True
            )
            output = torch.empty_like(q)

            def plan(
                length: int,
                *,
                n=n,
                max_pages=max_pages,
                indptr=indptr,
                indices=indices,
                last_page=last_page,
                wrapper=wrapper,
            ):
                lengths = [length + i for i in range(n)]
                pointers = [0]
                pages = []
                for i, seq_len in enumerate(lengths):
                    count = math.ceil(seq_len / page_size)
                    pages.extend(range(i * max_pages, i * max_pages + count))
                    pointers.append(len(pages))
                host_ptr = torch.tensor(pointers, dtype=torch.int32).pin_memory()
                host_last = torch.tensor(
                    [(seq_len - 1) % page_size + 1 for seq_len in lengths],
                    dtype=torch.int32,
                ).pin_memory()
                indptr.copy_(host_ptr, non_blocking=True)
                last_page.copy_(host_last, non_blocking=True)
                indices[: len(pages)].copy_(
                    torch.tensor(pages, dtype=torch.int32, device=device)
                )
                fast_plan_decode(
                    wrapper,
                    host_ptr,
                    indices[: len(pages)],
                    host_last,
                    torch.tensor(lengths, dtype=torch.int32).pin_memory(),
                    args.qo_heads,
                    args.kv_heads,
                    args.head_dim,
                    page_size,
                    q_data_type=torch.bfloat16,
                    kv_data_type=torch.float8_e4m3fn,
                    o_data_type=torch.bfloat16,
                )
                return host_ptr, host_last, len(pages)

            plan(boundaries[0])
            for _ in range(2):
                wrapper.run(q, kv, out=output)
            torch.cuda.synchronize(device)
            graph = torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):
                wrapper.run(q, kv, out=output)
            buffer_names = (
                "_paged_kv_indptr_buf",
                "_paged_kv_indices_buf",
                "_paged_kv_last_page_len_buf",
            )
            pointers = tuple(getattr(wrapper, name).data_ptr() for name in buffer_names)
            for length in boundaries:
                q.copy_(torch.randn_like(q))
                host_ptr, host_last, num_pages = plan(length)
                reference.plan(
                    host_ptr,
                    indices[:num_pages],
                    host_last,
                    args.qo_heads,
                    args.kv_heads,
                    args.head_dim,
                    page_size,
                    q_data_type=torch.bfloat16,
                    kv_data_type=torch.float8_e4m3fn,
                    o_data_type=torch.bfloat16,
                )
                expected = reference.run(q, kv)
                graph.replay()
                torch.cuda.synchronize(device)
                assert pointers == tuple(
                    getattr(wrapper, name).data_ptr() for name in buffer_names
                ), "A graph metadata buffer address changed"
                torch.testing.assert_close(output, expected, rtol=0.02, atol=0.001)
                checked += 1
            print(
                f"PASS: requests={n}, {len(boundaries)} lengths, FP8 KV, fixed buffers"
            )
            del plan, graph, wrapper, reference, kv, q, output
            del workspace, reference_workspace
            torch.cuda.empty_cache()
    print(
        f"PASS: {checked} graph-vs-eager comparisons. Full-model/TP validation remains."
    )


if __name__ == "__main__":
    main()
