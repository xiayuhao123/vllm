# L40 / v0.30.0 / FI071：独立 MTP decode CUDA Graph 实验包

本包合并了 V2 sampler warmup、A 的 Split-K 命中日志和新的独立 MTP decode
graph 实验。无需先安装中间的 v2w1 包。直接叠加在已有 FI071/A 镜像上，
保留 PyTorch、FlashInfer 和全部 CUDA 扩展，不下载依赖、不重新编译扩展。

## 改了什么

- 主模型保持 PIECEWISE，MTP 第一步保持原来的执行路径。
- 为后续草稿步骤创建私有 FULL_DECODE_ONLY 配置，仅重建草稿 attention builders。
  主模型配置和 target attention builders 不被修改。
- 复用 FlashInfer 原有的 graph-enabled decode wrapper：固定 indptr、indices、
  last-page-length GPU buffer 地址，按请求数缓存 wrapper；每步在 graph 外更新
  slot mapping、序列长度和 plan，再回放包含 draft forward/logits/sample/input
  update 的 graph。不是复用第一步的旧 metadata。
- graph 只捕获精确的 1..8 个请求，受 max_num_seqs、token budget 和 capture
  上限限制；不回放 padded graph，超出捕获范围使用原执行方式。
- 不启用 fused multi-step；保留每步 metadata 构建及其 CPU/GPU 同步。
- 增加 enable/skip/captured/replay/eager fallback 日志。`replay` 才表明运行时
  选择了实验 graph；仅看到 `captured` 不代表真实请求使用了它。

新开关 `VLLM_ENABLE_SM89_MTP_DECODE_GRAPH=1`，代码默认关闭。
范围限定 CUDA SM89、dense Qwen3_5MTP、至少 2 个草稿 token、FlashInfer、
TP1/2、PP/DP/DCP/PCP=1、主模型 PIECEWISE。LoRA、DBO、KV transfer、weight
offloading、水印、adaptive/dynamic speculation 不在本次范围，会记录跳过原因。
这里按实际解析出的 architecture 匹配，不按模型目录名称匹配；你此前的
Qwen3.8-27B 日志使用 Qwen3_5MTP，因此属于候选范围。

这是未经本地 L40 验证的候选，不能预先认定更快或数值正确。FlashInfer 固定
wrapper 的 plan、GPU 指针以及整模型/TP 行为仍需目标 GPU 验证。capture 或
replay 出错不吞掉异常；关闭开关后重启，可回到原草稿执行路径。

## 内网构建：只打一张候选镜像

```bash
tar -xzf vllm-l40-v030-mtp-graph-offline.tar.gz
cd vllm-l40-v030-mtp-graph-offline
sha256sum -c SHA256SUMS

docker build --progress=plain --pull=false --network=none \
  --build-arg BASE_IMAGE=vllm/vllm-openai:v0.30.0-l40-a-fi071 \
  -t vllm/vllm-openai:v0.30.0-l40-a-fi071-mtpgraph1 .
```

BASE_IMAGE 必须是内网已安装 FI071 的实际镜像名。构建检查 vLLM=0.30.0、
flashinfer-python=0.7.0.post1、原始源码/补丁哈希和 Python 语法。新 helper 文件
必须原本不存在或已经是同一补丁；其他已有文件必须与 A 基础源码或本补丁匹配。
之前的 v2w1 三个文件与本包相同，因此以已经安装 v2w1 的 FI071 镜像为基础也
可以校验通过。报 Base source mismatch 时，应先核对已有源码修改，不删校验。

构建只覆盖 6 个 Python 文件，不需要 GPU，几秒完成是正常的。后端内核在 GPU
启动/预热时编译；首次启用 graph 会增加捕获工作。

## 启动与回退

等下次换版时先停止占用 GPU 2、3 的原容器，再运行：

```bash
MTP_DRAFT_GRAPH=1 bash launch.sh
```

新容器名 `qwen38-fp8-30-l40-mtpgraph1`，端口仍为 18013。
脚本保留 TP2、MTP3、Triton、A=1、PCIe=1、FP8 KV、8192 token budget、
262144 max model len、0.90 memory utilization 及原 API/parser 参数。
可通过 NEW_IMAGE、CONTAINER_NAME、GPU_DEVICES、HOST_PORT、CACHE_DIR 覆盖相应值。

回到原草稿路径：停止当前容器，然后用同一候选镜像执行：

```bash
MTP_DRAFT_GRAPH=0 bash launch.sh
```

不必再次构建镜像；warmup 和 Split-K 命中日志仍保留。开关不能在已启动的服务
进程中热切换。完全回滚则使用之前的 FI071/A 镜像。

脚本持久化 vLLM、Triton 和 FlashInfer 编译/调优缓存，默认宿主目录
`/model/vllm-runtime-cache/l40-fi071-mtpgraph1`，对应容器路径分别为
`/root/.cache/vllm`、`/root/.triton/cache`、`/root/.cache/flashinfer`。
Triton 路径用 TRITON_CACHE_DIR 显式指定。若基础镜像改变了
FLASHINFER_WORKSPACE_BASE，要同步调整 FlashInfer 挂载路径。
第一次新目录无缓存，后续正常重启才能复用；CUDA Graph 本身仍须重新捕获。
编译缓存不等于 prefix cache，不影响 benchmark 每轮 reset 的冷提示词条件。

## 一起验证：不重做四组消融

1. 确认服务 ready，检查日志。主模型的 PIECEWISE 警告和不支持 fused
   multi-step 的消息仍可能出现，本补丁没有更改这些能力标志。

```bash
bash collect_logs.sh
```

应看到类似：

```text
Independent MTP decode CUDA Graph enabled: target=PIECEWISE, draft=FULL_DECODE_ONLY ...
Capturing decode CUDA graphs (FULL) ...
Independent MTP decode CUDA Graph captured: request counts=[1, 2, 3, 4, 5, 6, 7, 8]
```

内存 profiling 会有一轮临时捕获，随后真实 KV cache 分配后再次捕获。
不能把第一次临时捕获日志当成服务最终的 graph 状态。

2. 可先跑快速 GPU primitive 检查，不需要重新加载模型，不要与计时 benchmark
   同时运行。此脚本使用可见 cuda:0（当前部署对应物理 GPU 2）。

```bash
docker exec qwen38-fp8-30-l40-mtpgraph1 python3 \
  /opt/vllm-l40/check_flashinfer_decode_graph.py
```

脚本用 BF16 query / FP8 KV 比较 fixed-wrapper graph 与动态 wrapper 的输出，
覆盖请求数 1/3/4、64-token KV 页边界和 16K 附近的 12 个长度。
另外可用 --head-dim、--qo-heads、--kv-heads 匹配实际 attention shape。
它只验证 FlashInfer primitive，不验证完整 MTP、GDN、模型质量或 TP2 通信。
首次使用新的 attention shape 可能触发 FlashInfer JIT。

3. 整模型至少确认回复正常。若旧服务仍运行，可在升级前保存固定 seed 的
   greedy 回复，升级后用相同请求再保存；这一步不要求重跑长 benchmark。

```bash
curl -sS http://127.0.0.1:18013/v1/chat/completions \
  -H 'Content-Type: application/json' \
  -d '{"model":"/model/Qwen/Qwen3.8-27B-FP8","messages":[{"role":"user","content":"按顺序写出整数 1 到 40，用逗号分隔，不添加其他文字。"}],"temperature":0,"seed":12345,"max_tokens":256,"chat_template_kwargs":{"enable_thinking":false}}' \
  > greedy-after.json
```

升级前同一命令把文件名设成 greedy-before.json。比较消息内容和 finish_reason，
不要比较 request id/time；仅一条回复一致不足以证明全模型正确性。若有差异，
应先记录并排查；GPU 算子与请求调度并非全部保证逐 token 的 batch invariance。

4. 沿用你原来的五轮 benchmark、随机数据、采样方式和每轮 prefix reset，
   只换 TEST_NAME 防止覆盖旧数据。测试后、停止 --rm 容器之前执行：

```bash
bash collect_logs.sh qwen38-fp8-30-l40-mtpgraph1 mtpgraph1-after-bench
```

四并发的运行日志应出现：

```text
Independent MTP decode CUDA Graph replay: requests=4, step=1.
Independent MTP decode CUDA Graph replay: requests=4, step=2.
```

step 从 0 开始，所以 step=1/2 是 MTP 第 2/3 步。请求收尾时可出现 requests=3/2/1。
以上日志按形状/step 打印一次，不是逐次计数器；capture 日志不能代替 replay。
benchmark 应成功完成全部请求，观察输出、TPOT/ITL、MTP 接受率及接受长度。
这个改动针对 decode 重复调用开销；16K prefill 的 TTFT 不一定改善，整体输出
吞吐也不能当成纯 decode 吞吐。

已有四组数据保留。若需要分离 graph 的增量收益，后续最多补同一候选镜像的
flag=0 一组，并保持其他参数不变；无需重新打镜像或重做四组。首次请求 JIT
状态仍须记录，不选择性剔除某一组首轮后声称收益。

## 本地验证范围

CPU 检查覆盖私有配置与主配置隔离、不兼容配置回退、精确形状/上限、非固定
wrapper 阻止 replay、profiling/最终初始化创建新 builders、prefill/decode
manager 配置选择，以及每步先构建 metadata 再执行的控制流。GPU 分配、builder
和 graph 后端通过替身隔离；CUDA Graph 没有在本机执行。
另外运行原有 autoregressive graph 控制流检查、sampler 注册检查、安装器检查、
语法/Ruff、真实源码覆盖 smoke、shell 参数/日志过滤及 SHA256 校验。

当前开发机无 CUDA/L40，未验证 SM89 graph capture/replay、整模型数值、TP2
通信或性能。独立 graph 候选、sampler warmup、缓存挂载的收益应分别解释；
没有已验证的稳态 decode 提升数值。
