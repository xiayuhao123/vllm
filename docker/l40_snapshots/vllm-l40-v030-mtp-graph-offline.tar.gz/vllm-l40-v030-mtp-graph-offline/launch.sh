#!/usr/bin/env bash
set -euo pipefail

NEW_IMAGE="${NEW_IMAGE:-vllm/vllm-openai:v0.30.0-l40-a-fi071-mtpgraph1}"
CONTAINER_NAME="${CONTAINER_NAME:-qwen38-fp8-30-l40-mtpgraph1}"
GPU_DEVICES="${GPU_DEVICES:-2,3}"
HOST_PORT="${HOST_PORT:-18013}"
CACHE_DIR="${CACHE_DIR:-/model/vllm-runtime-cache/l40-fi071-mtpgraph1}"
MTP_DRAFT_GRAPH="${MTP_DRAFT_GRAPH:-0}"
mkdir -p "$CACHE_DIR/vllm" "$CACHE_DIR/triton" "$CACHE_DIR/flashinfer"

exec docker run --rm \
  --name "$CONTAINER_NAME" \
  --gpus "\"device=$GPU_DEVICES\"" \
  --ipc=host \
  -p "$HOST_PORT:8000" \
  -v /model:/model \
  -v "$CACHE_DIR/vllm:/root/.cache/vllm" \
  -v "$CACHE_DIR/triton:/root/.triton/cache" \
  -v "$CACHE_DIR/flashinfer:/root/.cache/flashinfer" \
  -e VLLM_CACHE_ROOT=/root/.cache/vllm \
  -e TRITON_CACHE_DIR=/root/.triton/cache \
  -e VLLM_ENABLE_CUDA_COMPATIBILITY=0 \
  -e VLLM_SERVER_DEV_MODE=1 \
  -e VLLM_ALLREDUCE_USE_FLASHINFER_PCIE_IPC=1 \
  -e VLLM_ENABLE_SM89_FP8_SPLIT_K=1 \
  -e "VLLM_ENABLE_SM89_MTP_DECODE_GRAPH=$MTP_DRAFT_GRAPH" \
  "$NEW_IMAGE" \
  /model/Qwen/Qwen3.8-27B-FP8 \
  --host 0.0.0.0 --port 8000 \
  --tensor-parallel-size 2 \
  --max-model-len 262144 \
  --kv-cache-dtype fp8 \
  --reasoning-parser qwen3 \
  --enable-auto-tool-choice \
  --tool-call-parser qwen3_coder \
  --enable-prefix-caching \
  --enable-prompt-tokens-details \
  --enable-force-include-usage \
  --enable-per-request-metrics \
  --enable-chunked-prefill \
  --speculative-config '{"method":"mtp","num_speculative_tokens":3}' \
  --kernel-config '{"linear_backend_per_quant":{"fp8_block_w8a8":"triton"}}' \
  --gpu-memory-utilization 0.90 \
  --max-num-batched-tokens 8192
