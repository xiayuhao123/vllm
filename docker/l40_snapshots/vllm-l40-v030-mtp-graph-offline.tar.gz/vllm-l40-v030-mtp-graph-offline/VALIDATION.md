# Local validation (2026-10-08)

Candidate code is based on the vLLM v0.30.0 L40 A checkout, HEAD
`784f5ee36d`. The installed-image payload is six Python modules, including a
new independent graph policy helper. FlashInfer's native fixed-buffer wrappers
and vLLM's existing `fast_plan_decode` implementation are reused unchanged.

## Passed locally

- 42 independent MTP graph policy/control-flow checks: opt-in eligibility,
  configuration identity/isolation, exact request counts, capture limits,
  wrapper metadata guards, rebuilding after profiling, manager separation and
  metadata-before-each-step execution.
- 4 existing autoregressive full-graph control-flow regressions (the matching
  subset of `test_gpu_autoregressive_speculator.py`; 15 unrelated cases excluded).
- 4 V2 sampler warmup registration checks, covering native fallback providers
  with FlashInfer enabled/disabled and CUDA/non-CUDA platform selection.
- 5 installer tests, including absent helper installation, repeated install,
  checksum/source rejection and syntax validation before mutation.
- Ruff lint/format, Python syntax compilation, shell syntax and Git diff checks.
- Patch application against the real baseline files; real installer application
  and repeated application; all six installed files matched payload bytes.
- Launch arguments (default-off/on, MTP3, Triton, budget8192, quoted GPU devices,
  cache mounts) and log filtering checked with a fake Docker CLI. No daemon or
  serving container was started for these checks.
- SHA256 manifests and archive contents verified after packaging.

Total: **55 passing isolated CPU tests**, plus the packaging/script checks.
The CPU harness imported the real changed Python code and the source definitions
of graph descriptors/enums, while replacing CUDA allocation, attention builders,
graph managers and unrelated GPU dependencies with test doubles. These are not
GPU integration tests or a full vLLM test-suite run.

## Still requires the user's L40 environment

- Building the image against the actual private-network base image.
- CUDA graph capture/replay and FlashInfer planning with stable GPU addresses.
- FP8 KV numerical comparison across page boundaries (optional supplied GPU
  primitive smoke script; this was syntax-checked but not executed locally).
- Complete Qwen3_5MTP inference, stochastic sampling, GDN and TP2 communication.
- Measured steady-state decode/TPOT/ITL and MTP acceptance behavior using the
  existing benchmark. No throughput or quality improvement is established here.

The feature remains experimental and defaults off. Use the runtime switch to
disable it and restart the same image if capture/replay fails. The original
FP8 KV scaling warnings are not calibrated or suppressed by this change.
